(function () {
    "use strict";

    $dyn.ui.defaults.DocClipboardHelper = {};

    // Initialize the DocClipboardHelper control
    $dyn.controls.DocClipboardHelper = function (data, element) {
        var self = this;

        $dyn.ui.Control.apply(self, arguments);
        $dyn.ui.applyDefaults(self, data, $dyn.ui.defaults.DocClipboardHelper);

        // The HTML element needs to be in focus to be able to use the copy to clipboard functionality properly.
        element.focus();

        // Triggers the copy to clipboard functionality from the browser. The _data variable contains the text to be copied
        $dyn.observe(this.SetTextJavascript, function (_data) {
            if (_data != '') {
                navigator.clipboard.writeText(_data);                
            }
        });
    }

    $dyn.controls.DocClipboardHelper.prototype = $dyn.extendPrototype($dyn.ui.Control.prototype, {});
})();